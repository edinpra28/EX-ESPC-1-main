// Ejecuta el código cuando el documento ya cargó
document.addEventListener("DOMContentLoaded", () => {

    // Botón y contenedores principales
    const btnAgregar = document.getElementById("btn-agregar");
    const pendientes = document.getElementById("pendientes");
    const realizadas = document.getElementById("realizadas");

    // Contadores de tareas
    const pendientesCount = document.getElementById("pendientes-count");
    const realizadasCount = document.getElementById("realizadas-count");

    // Evento para agregar tareas nuevas
    btnAgregar.addEventListener("click", () => {

        // Solicitar descripción
        let descripcion = prompt("Descripción de la tarea:");
        if (!descripcion) return; // Si no escribe nada, no se agrega

        // Solicitar prioridad al usuario
        let prioridad = prompt("Prioridad (Alta, Media, Baja):");
        if (!prioridad) prioridad = "Media"; // Valor por defecto

        prioridad = prioridad.toLowerCase();

        // Validar que sea una prioridad válida
        if (prioridad !== "alta" && prioridad !== "media" && prioridad !== "baja") {
            prioridad = "media";
        }

        // Crear la tarea
        agregarTarea(descripcion, prioridad);
    });

    /**
     * Crea una nueva tarea y la agrega a la lista de pendientes
     */
    function agregarTarea(texto, prioridad) {

        // Crear el contenedor visual de la tarea
        let div = document.createElement("div");
        div.classList.add("tarea", prioridad);

        // Texto mostrado
        div.textContent = `${texto} - Prioridad: ${prioridad}`;

        // Al hacer clic, se mueve a realizadas
        div.addEventListener("click", moverARealizadas);

        pendientes.appendChild(div);
        actualizarContadores();
    }

    /**
     * Mueve una tarea de pendientes a realizadas
     */
    function moverARealizadas(event) {
        let div = event.target;

        div.classList.add("realizada");

        // Evita que vuelva a ser clickeada
        div.removeEventListener("click", moverARealizadas);

        realizadas.appendChild(div);
        actualizarContadores();
    }

    /**
     * Actualiza los números de pendientes y realizadas
     */
    function actualizarContadores() {
        pendientesCount.textContent = pendientes.children.length;
        realizadasCount.textContent = realizadas.children.length;
    }

});

